using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace variables_and_datatypes_lecture
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
