﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture
{
    public partial class LectureProblem
    {
        /*
        2a. Return the first element of the array
            TOPIC: Accessing Array Elements
        */
        public int ReturnFirstElement()
        {
            int[] portNumbers = { 80, 8080, 443 };

            return portNumbers[0];
        }

        


    }
}
