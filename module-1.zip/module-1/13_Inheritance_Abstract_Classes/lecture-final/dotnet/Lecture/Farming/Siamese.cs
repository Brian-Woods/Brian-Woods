﻿using System;
using System.Collections.Generic;
using System.Text;
/*  since Cat is sealed, we cannot create a subclass where Cat is the superclass/parent
namespace Lecture.Farming
{
    class Siamese : Cat
    {
    }
}
*/