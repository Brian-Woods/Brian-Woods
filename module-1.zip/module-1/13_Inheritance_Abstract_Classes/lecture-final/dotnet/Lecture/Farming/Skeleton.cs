﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture.Farming
{
    abstract class Skeleton : FarmAnimal
    {
        public Skeleton():base("skelley")
        { }

    }
}
