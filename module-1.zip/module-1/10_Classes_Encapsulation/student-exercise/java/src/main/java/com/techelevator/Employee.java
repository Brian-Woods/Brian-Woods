package com.techelevator;

public class Employee {

}
