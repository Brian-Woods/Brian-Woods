package com.techelevator;

public class Airplane {

}
