using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestableClassesTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
