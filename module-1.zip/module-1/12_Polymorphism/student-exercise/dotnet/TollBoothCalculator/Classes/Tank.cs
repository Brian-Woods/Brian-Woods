﻿using System;
using System.Collections.Generic;
using System.Text;
using TollBoothCalculator;

namespace TollBoothCalculator.Classes
{
    public class Tank : IVehicle
    {

        public Tank()
        {

        }

        public double CalculateToll(int distance)
        {
            double tollAmount = 0.0;
            return tollAmount;
        }

    }
}
