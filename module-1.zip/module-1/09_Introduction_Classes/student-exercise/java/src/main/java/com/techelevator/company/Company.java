package com.techelevator.company;

public class Company {

	//
	// Write code here
	//
	
}
