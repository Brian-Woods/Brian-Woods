package com.techelevator.dog;

public class Dog {

	//
	// Write code here
	//
	
}
