package com.techelevator.person;

public class Person {

	//
	// Write code here
	//
	
}
