package com.techelevator.product;

public class Product {

	//
	// Write code here
	//
	
}
