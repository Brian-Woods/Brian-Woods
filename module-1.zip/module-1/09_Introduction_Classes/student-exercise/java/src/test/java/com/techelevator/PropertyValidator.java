package com.techelevator;

public class PropertyValidator {

    public static void validateReadOnly(Class<?> klass, String name, Class expectedType) {

    }
}