﻿using System;

//using public static class math;
// need to use something to use power

namespace CalculatorExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }

      
    
}
