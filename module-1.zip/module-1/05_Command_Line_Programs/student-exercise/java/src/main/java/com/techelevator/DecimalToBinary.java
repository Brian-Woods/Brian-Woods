package com.techelevator;

public class DecimalToBinary {

	public static void main(String[] args) {

	}

}
