package com.techelevator;

public class Fibonacci {

	public static void main(String[] args) {

	}

}
