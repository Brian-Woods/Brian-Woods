package com.techelevator;

public class TempConvert {

	public static void main(String[] args) {

	}

}
