package com.techelevator;

public class LinearConvert {

	public static void main(String[] args) {

	}

}
