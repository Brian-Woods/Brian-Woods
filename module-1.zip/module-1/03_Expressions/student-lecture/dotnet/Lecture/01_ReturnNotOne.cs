﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture
{
    public partial class LectureExample
    {
        /*
        1. This method is named ReturnNotOne and it returns an int. 
        Change it so that it still returns an int but something other than 1.
        TOPIC: Method Signatures & Tests
        */
        public int ReturnNotOne()
        {
            return 2;
        }
    }
}
