﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture
{
    public partial class LectureExample
    {
        /*
         4. This method currently returns an int. Change it so that it returns a double.
            TOPIC: Return Types
         */
        public double ReturnDoubleOfTwo()
        {
            return 2.0;
        }
    }
}
