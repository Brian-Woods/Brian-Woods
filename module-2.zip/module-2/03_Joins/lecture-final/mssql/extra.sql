-- Display all the films and their language

-- Display all the films and in English

-- Display all the films with their category

-- Display all the films with a category of Horror

-- Display all the films with a category of Horror and title that begins with the letter F

-- Who acted in what together?

-- How many times have two actors appeared together?

-- What movies did the two most often acted together actors appear in together?
