namespace DataSecurity.Cli.Model
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
    }
}